import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import OpenAI from 'openai';
import Anthropic from '@anthropic-ai/sdk';

const HARDCODED_OPENAI_KEY = "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";
const HARDCODED_ANTHROPIC_KEY = "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";

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '1mb' }));

// Health check
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, providerStatuses: {
    openai: Boolean('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'),
    anthropic: Boolean('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'),
  }});
});

// Unified AI endpoint
app.post('/api/ai', async (req, res) => {
  try {
    const { provider = 'openai', messages = [], system, model } = req.body || {};

    if (provider === 'openai') {
      const client = new OpenAI({ apiKey: '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' });
      const response = await client.chat.completions.create({
        model: model || 'gpt-4o-mini',
        messages: [
          ...(system ? [{ role: 'system', content: system }] : []),
          ...messages,
        ],
        temperature: 0.3,
      });
      const text = response.choices?.[0]?.message?.content ?? '';
      return res.json({ provider, model: model || 'gpt-4o-mini', text, raw: response });
    }

    if (provider === 'anthropic') {
      const client = new Anthropic({ apiKey: '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' });
      const response = await client.messages.create({
        model: model || 'claude-3-5-sonnet-20240620',
        max_tokens: 800,
        system,
        messages: messages.map(m => ({
          role: m.role === 'assistant' ? 'assistant' : 'user',
          content: typeof m.content === 'string' ? m.content : JSON.stringify(m.content)
        })),
        temperature: 0.3,
      });
      const text = response.content?.map(p => p.type === 'text' ? p.text : '').join('').trim();
      return res.json({ provider, model: model || 'claude-3-5-sonnet-20240620', text, raw: response });
    }

    return res.status(400).json({ error: 'Unknown provider. Use openai or anthropic.' });
  } catch (err) {
    console.error(err);
    const msg = err?.message || 'Unknown error';
    res.status(500).json({ error: msg });
  }
});

const port = process.env.PORT || 8787;
app.listen(port, () => {
  console.log(`AI proxy server listening on http://localhost:${port}`);
});