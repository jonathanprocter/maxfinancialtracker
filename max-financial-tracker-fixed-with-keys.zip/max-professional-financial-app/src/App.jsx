import React, { useState, useEffect, useMemo } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  Target, 
  BookOpen, 
  Database,
  Plus,
  Minus,
  Check,
  X,
  Settings,
  Download,
  MessageCircle,
  Zap,
  Award,
  Calendar,
  PiggyBank,
  CreditCard,
  Home,
  BarChart3,
  Brain,
  Send,
  Trash2,
  RotateCcw,
  Bell,
  Shield,
  Edit3,
  Save,
  ChevronRight,
  Star,
  TrendingDown,
  HelpCircle,
  Calculator,
  Clock,
  AlertCircle,
  CheckCircle,
  Info
} from 'lucide-react';
import { Button } from '@/components/ui/button.jsx';
import './App.css';

// Custom hook for responsive behavior
const useResponsive = () => {
  const [windowSize, setWindowSize] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 1200,
    height: typeof window !== 'undefined' ? window.innerHeight : 800,
  });

  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return {
    isMobile: windowSize.width < 768,
    isTablet: windowSize.width >= 768 && windowSize.width < 1024,
    isDesktop: windowSize.width >= 1024,
    width: windowSize.width,
    height: windowSize.height,
  };
};

// Enhanced notification system
const useNotifications = () => {
  const [notifications, setNotifications] = useState([]);

  const addNotification = (message, type = 'info') => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  return { notifications, addNotification };
};

// Main App Component
function App() {
  const responsive = useResponsive();
  const { notifications, addNotification } = useNotifications();
  
  // State management
  const [activeTab, setActiveTab] = useState('home');
  const [showAIModal, setShowAIModal] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState('openai');
  const [aiConversation, setAiConversation] = useState([]);
  const [aiInput, setAiInput] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showExpenseModal, setShowExpenseModal] = useState(false);
  const [showGoalSetup, setShowGoalSetup] = useState(false);
  const [expenseForm, setExpenseForm] = useState({
    amount: '',
    description: '',
    category: 'Food & Dining',
    date: new Date().toISOString().split('T')[0]
  });

  // Enhanced financial data state with personalization
  const [data, setData] = useState(() => {
    const saved = localStorage.getItem('maxFinancialData');
    return saved ? JSON.parse(saved) : {
      // Personal Information
      monthlyIncome: 4100,
      fixedExpenses: {
        rent: 1200,
        utilities: 150,
        insurance: 200,
        phone: 80,
        internet: 60,
        minimumDebtPayments: 150,
        other: 200
      },
      debts: {
        creditCard: 4284,
        paymentPlan: 850
      },
      goals: {
        emergencyFund: 1000,
        debtFreeDate: '2026-10-01',
        customGoals: []
      },
      preferences: {
        aggressivePayoff: false,
        prioritizeEmergency: true,
        riskTolerance: 'moderate'
      },
      // Tracking data
      expenses: [],
      dailyGoals: {
        trackExpenses: false,
        stayUnderBudget: false,
        addToEmergency: false,
        makeDebtPayment: false
      },
      streak: 1,
      level: 1,
      emergencyFund: 0,
      debtPayments: 0,
      totalSaved: 0,
      setupComplete: false
    };
  });

  // Save data to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('maxFinancialData', JSON.stringify(data));
  }, [data]);

  // Intelligent budget calculations with explanations
  const calculations = useMemo(() => {
    const totalFixedExpenses = Object.values(data.fixedExpenses).reduce((sum, expense) => sum + expense, 0);
    const totalDebt = data.debts.creditCard + data.debts.paymentPlan;
    const netIncome = data.monthlyIncome - totalFixedExpenses;
    
    // Calculate recommended daily allowance based on goals and timeline
    const debtFreeDate = new Date(data.goals.debtFreeDate);
    const today = new Date();
    const monthsToDebtFree = Math.max(1, Math.ceil((debtFreeDate - today) / (1000 * 60 * 60 * 24 * 30)));
    
    // Calculate minimum monthly debt payment needed
    const debtRemaining = Math.max(0, totalDebt - data.debtPayments);
    const minimumMonthlyDebtPayment = Math.ceil(debtRemaining / monthsToDebtFree);
    
    // Calculate emergency fund contribution
    const emergencyRemaining = Math.max(0, data.goals.emergencyFund - data.emergencyFund);
    const monthlyEmergencyContribution = data.preferences.prioritizeEmergency ? 
      Math.min(200, emergencyRemaining / Math.max(1, monthsToDebtFree * 0.5)) : 50;
    
    // Calculate available for discretionary spending
    const monthlyDiscretionary = netIncome - minimumMonthlyDebtPayment - monthlyEmergencyContribution;
    const dailyAllowance = Math.max(20, monthlyDiscretionary / 30); // Minimum $20/day
    
    // Today's expenses
    const todayExpenses = data.expenses
      .filter(expense => {
        const expenseDate = new Date(expense.date);
        const today = new Date();
        return expenseDate.toDateString() === today.toDateString();
      })
      .reduce((sum, expense) => sum + expense.amount, 0);

    const budgetRemaining = dailyAllowance - todayExpenses;
    const debtProgress = ((data.debtPayments / totalDebt) * 100);
    const emergencyProgress = ((data.emergencyFund / data.goals.emergencyFund) * 100);
    const independenceScore = Math.round((debtProgress * 0.6) + (emergencyProgress * 0.4));

    // Budget explanation
    const budgetExplanation = {
      monthlyIncome: data.monthlyIncome,
      totalFixedExpenses,
      netIncome,
      minimumMonthlyDebtPayment,
      monthlyEmergencyContribution,
      monthlyDiscretionary,
      dailyAllowance,
      reasoning: `Your $${dailyAllowance.toFixed(2)} daily allowance is calculated from your $${data.monthlyIncome} monthly income minus $${totalFixedExpenses} in fixed expenses, leaving $${netIncome} net income. After allocating $${minimumMonthlyDebtPayment} for debt payments and $${monthlyEmergencyContribution.toFixed(2)} for emergency savings to meet your ${data.goals.debtFreeDate} debt-free goal, you have $${monthlyDiscretionary.toFixed(2)} monthly ($${dailyAllowance.toFixed(2)} daily) for discretionary spending.`
    };

    return {
      totalFixedExpenses,
      totalDebt,
      netIncome,
      dailyAllowance,
      todayExpenses,
      budgetRemaining,
      debtRemaining,
      debtProgress,
      emergencyProgress,
      independenceScore,
      budgetExplanation,
      monthsToDebtFree,
      minimumMonthlyDebtPayment,
      monthlyEmergencyContribution
    };
  }, [data]);

  // Enhanced AI interaction with context awareness
  const handleAIQuestion = async (question) => {
    setAiLoading(true);
    const userMessage = { role: 'user', content: question, timestamp: new Date().toLocaleTimeString() };
    setAiConversation(prev => [...prev, userMessage]);

    try {
      // Use the global OPENAI_API_KEY environment variable that's already set in the sandbox
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: selectedProvider || 'openai',
          model: selectedProvider === 'anthropic' ? 'claude-3-5-sonnet-20240620' : 'gpt-4o-mini',
          system: `You are Fin, Max Moskowitz's intelligent AI financial coach.`,
          messages: [
            { role: 'system', content: `You are Fin, Max Moskowitz's intelligent AI financial coach.` },
            { role: 'user', content: question }
          ]
        })
      });

      if (response.ok) {
        const result = await response.json();
        const aiMessage = { 
          role: 'assistant', 
          content: result.choices[0].message.content,
          timestamp: new Date().toLocaleTimeString()
        };
        setAiConversation(prev => [...prev, aiMessage]);
      } else {
        throw new Error('AI service unavailable');
      }
    } catch (error) {
      const errorMessage = { 
        role: 'assistant', 
        content: `Hi Max! I'm having trouble connecting right now, but I can still help! Your $${calculations.dailyAllowance.toFixed(2)} daily budget comes from your $${data.monthlyIncome} monthly income minus $${calculations.totalFixedExpenses} in fixed expenses, leaving $${calculations.netIncome} for debt payments, emergency savings, and daily spending. You have $${calculations.budgetRemaining.toFixed(2)} left today - great job staying on track!`,
        timestamp: new Date().toLocaleTimeString()
      };
      setAiConversation(prev => [...prev, errorMessage]);
    }
    
    setAiLoading(false);
    setAiInput('');
  };

  // Goal setup modal
  const GoalSetupModal = () => {
    if (!showGoalSetup) return null;

    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-3xl shadow-2xl border border-[#DEDEDE] w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <div className="p-8">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-gradient-to-br from-[#4A6B8A] to-[#C4A8A8] rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Target className="w-10 h-10 text-white" />
              </div>
              <h2 className="text-3xl font-bold text-[#1A1A1A] mb-3">Let's Personalize Your Financial Plan</h2>
              <p className="text-[#1A1A1A]/70 text-lg">Help me understand your goals so I can create the perfect plan for you</p>
            </div>

            <div className="space-y-8">
              <div>
                <label className="block text-lg font-semibold text-[#1A1A1A] mb-4">When do you want to be debt-free?</label>
                <input
                  type="date"
                  value={data.goals.debtFreeDate}
                  onChange={(e) => setData(prev => ({
                    ...prev,
                    goals: { ...prev.goals, debtFreeDate: e.target.value }
                  }))}
                  className="w-full px-4 py-3 border border-[#DEDEDE] rounded-xl focus:ring-2 focus:ring-[#4A6B8A] focus:border-[#4A6B8A] text-lg"
                />
                <p className="text-sm text-[#1A1A1A]/70 mt-2">This affects how much you need to pay toward debt each month</p>
              </div>

              <div>
                <label className="block text-lg font-semibold text-[#1A1A1A] mb-4">Emergency fund goal</label>
                <input
                  type="number"
                  value={data.goals.emergencyFund}
                  onChange={(e) => setData(prev => ({
                    ...prev,
                    goals: { ...prev.goals, emergencyFund: parseInt(e.target.value) || 1000 }
                  }))}
                  className="w-full px-4 py-3 border border-[#DEDEDE] rounded-xl focus:ring-2 focus:ring-[#4A6B8A] focus:border-[#4A6B8A] text-lg"
                />
                <p className="text-sm text-[#1A1A1A]/70 mt-2">Recommended: 3-6 months of expenses ($3,000-$6,000)</p>
              </div>

              <div>
                <label className="block text-lg font-semibold text-[#1A1A1A] mb-4">Your approach to debt payoff</label>
                <div className="space-y-3">
                  <label className="flex items-center space-x-3 p-4 border border-[#DEDEDE] rounded-xl hover:bg-[#C4A8A8]/5 cursor-pointer">
                    <input
                      type="radio"
                      name="approach"
                      checked={!data.preferences.aggressivePayoff}
                      onChange={() => setData(prev => ({
                        ...prev,
                        preferences: { ...prev.preferences, aggressivePayoff: false }
                      }))}
                      className="w-4 h-4 text-[#4A6B8A]"
                    />
                    <div>
                      <p className="font-semibold text-[#1A1A1A]">Balanced approach</p>
                      <p className="text-sm text-[#1A1A1A]/70">Pay minimums while building emergency fund</p>
                    </div>
                  </label>
                  <label className="flex items-center space-x-3 p-4 border border-[#DEDEDE] rounded-xl hover:bg-[#C4A8A8]/5 cursor-pointer">
                    <input
                      type="radio"
                      name="approach"
                      checked={data.preferences.aggressivePayoff}
                      onChange={() => setData(prev => ({
                        ...prev,
                        preferences: { ...prev.preferences, aggressivePayoff: true }
                      }))}
                      className="w-4 h-4 text-[#4A6B8A]"
                    />
                    <div>
                      <p className="font-semibold text-[#1A1A1A]">Aggressive payoff</p>
                      <p className="text-sm text-[#1A1A1A]/70">Focus all extra money on debt elimination</p>
                    </div>
                  </label>
                </div>
              </div>

              <div className="flex space-x-4 pt-6">
                <Button
                  variant="outline"
                  onClick={() => setShowGoalSetup(false)}
                  className="flex-1 py-4 text-lg border-[#DEDEDE] hover:bg-[#A67676]/10 hover:border-[#A67676] rounded-xl"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => {
                    setData(prev => ({ ...prev, setupComplete: true }));
                    setShowGoalSetup(false);
                    addNotification('Your personalized plan has been created!', 'success');
                  }}
                  className="flex-1 py-4 text-lg bg-gradient-to-r from-[#4A6B8A] to-[#C4A8A8] text-white rounded-xl hover:from-[#4A6B8A]/90 hover:to-[#C4A8A8]/90 shadow-lg"
                >
                  Create My Plan
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Enhanced navigation with working tabs
  const Navigation = () => (
    <nav className="bg-white border-b border-[#DEDEDE] sticky top-0 z-40 shadow-lg backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-[#A67676] to-[#4A6B8A] rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-lg transform hover:scale-105 transition-transform duration-200">
              M
            </div>
            <div>
              <h1 className="text-2xl font-bold text-[#1A1A1A] tracking-tight">Max's Financial Journey</h1>
              <p className="text-sm text-[#1A1A1A]/70 font-medium">AI-Powered Independence Tracker</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowGoalSetup(true)}
              className="w-12 h-12 rounded-xl border-[#DEDEDE] hover:bg-[#C4A8A8]/10 hover:border-[#C4A8A8] transition-all duration-200"
            >
              <Target className="w-5 h-5 text-[#1A1A1A]" />
            </Button>
            
            <Button
              variant="outline"
              size="icon"
              onClick={() => setShowSettings(true)}
              className="w-12 h-12 rounded-xl border-[#DEDEDE] hover:bg-[#C4A8A8]/10 hover:border-[#C4A8A8] transition-all duration-200"
            >
              <Settings className="w-5 h-5 text-[#1A1A1A]" />
            </Button>
          </div>
        </div>
        
        <div className="flex space-x-2 overflow-x-auto pb-4 scrollbar-hide">
          {[
            { id: 'home', label: 'Overview', icon: Home, color: '#C4A8A8' },
            { id: 'daily', label: 'Daily', icon: Calendar, color: '#4A6B8A' },
            { id: 'expenses', label: 'Expenses', icon: CreditCard, color: '#A67676' },
            { id: 'progress', label: 'Progress', icon: BarChart3, color: '#9BAE8F' },
            { id: 'learn', label: 'Learn', icon: BookOpen, color: '#C4A8A8' },
            { id: 'data', label: 'Data', icon: Database, color: '#4A6B8A' }
          ].map(tab => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "ghost"}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center justify-center min-w-[100px] h-12 px-6 rounded-xl text-sm font-semibold transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-[#C4A8A8] to-[#4A6B8A] text-white shadow-lg transform scale-105'
                  : 'text-[#1A1A1A] hover:bg-[#C4A8A8]/10 hover:text-[#C4A8A8] border border-transparent hover:border-[#DEDEDE]'
              }`}
            >
              <tab.icon className="w-4 h-4 mr-2" />
              {tab.label}
            </Button>
          ))}
        </div>
      </div>
    </nav>
  );

  // Budget explanation component
  const BudgetExplanation = () => (
    <div className="bg-gradient-to-r from-[#4A6B8A]/5 to-[#C4A8A8]/5 rounded-2xl p-6 border border-[#DEDEDE]">
      <div className="flex items-start space-x-4">
        <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br from-[#4A6B8A] to-[#C4A8A8] shadow-lg flex-shrink-0">
          <Calculator className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <h4 className="text-lg font-bold text-[#1A1A1A] mb-3 flex items-center">
            Why $${calculations.dailyAllowance.toFixed(2)} per day?
            <HelpCircle className="w-5 h-5 ml-2 text-[#4A6B8A]" />
          </h4>
          <div className="space-y-3 text-[#1A1A1A]/80">
            <div className="flex justify-between items-center py-2 border-b border-[#DEDEDE]/50">
              <span>Monthly Income</span>
              <span className="font-semibold text-[#9BAE8F]">+${data.monthlyIncome}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-[#DEDEDE]/50">
              <span>Fixed Expenses</span>
              <span className="font-semibold text-[#A67676]">-${calculations.totalFixedExpenses}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-[#DEDEDE]/50">
              <span>Debt Payments (to reach {data.goals.debtFreeDate})</span>
              <span className="font-semibold text-[#A67676]">-${calculations.minimumMonthlyDebtPayment}</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-[#DEDEDE]/50">
              <span>Emergency Fund Savings</span>
              <span className="font-semibold text-[#4A6B8A]">-${calculations.monthlyEmergencyContribution.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center py-3 bg-[#C4A8A8]/10 rounded-xl px-4 font-bold text-lg">
              <span>Available for Daily Spending</span>
              <span className="text-[#4A6B8A]">${calculations.dailyAllowance.toFixed(2)}/day</span>
            </div>
          </div>
          <p className="text-sm text-[#1A1A1A]/70 mt-4 italic">
            This budget automatically adjusts when your income, expenses, or goals change. 
            Click the target icon above to modify your goals anytime.
          </p>
        </div>
      </div>
    </div>
  );

  // Home tab content
  const HomeContent = () => (
    <div className="space-y-8">
      {!data.setupComplete && (
        <div className="bg-gradient-to-r from-[#4A6B8A] to-[#C4A8A8] rounded-3xl p-8 text-white shadow-2xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold mb-3">Welcome to your personalized financial tracker!</h2>
              <p className="text-white/90 mb-4">Let's set up your goals to create the perfect plan for you.</p>
              <Button
                onClick={() => setShowGoalSetup(true)}
                className="bg-white text-[#4A6B8A] hover:bg-white/90 font-semibold px-6 py-3 rounded-xl"
              >
                Set Up My Goals
              </Button>
            </div>
            <Target className="w-16 h-16 text-white/70" />
          </div>
        </div>
      )}

      <div className="bg-gradient-to-br from-[#4A6B8A] via-[#A67676] to-[#C4A8A8] rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute inset-0 bg-white/5 backdrop-blur-sm"></div>
        <div className="relative z-10">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-3xl font-bold mb-3">Welcome back, Max! 👋</h2>
              <p className="text-white/90 mb-4 text-lg">Day {data.streak} of your financial independence journey</p>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2 border border-white/20">
                  <Zap className="w-5 h-5" />
                  <span className="font-semibold">{data.streak} day streak</span>
                </div>
                <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm rounded-xl px-4 py-2 border border-white/20">
                  <Award className="w-5 h-5" />
                  <span className="font-semibold">Level {data.level}</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <p className="text-white/80 mb-2 text-sm font-medium">Daily Goals</p>
              <p className="text-5xl font-bold mb-2">
                {Object.values(data.dailyGoals).filter(Boolean).length}/4
              </p>
              <p className="text-white/80 text-sm">completed</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-[#DEDEDE] p-8 shadow-xl hover:shadow-2xl transition-shadow duration-300">
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-14 h-14 bg-gradient-to-br from-[#9BAE8F] to-[#4A6B8A] rounded-2xl flex items-center justify-center shadow-lg">
            <DollarSign className="w-7 h-7 text-white" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-[#1A1A1A]">Today's Budget</h3>
            <p className="text-[#1A1A1A]/70 text-lg">Your personalized ${calculations.dailyAllowance.toFixed(2)} daily allowance</p>
          </div>
        </div>
        
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <span className="text-lg font-semibold text-[#1A1A1A]">Spent Today</span>
            <span className="text-3xl font-bold text-[#1A1A1A]">
              ${calculations.todayExpenses.toFixed(2)} / ${calculations.dailyAllowance.toFixed(2)}
            </span>
          </div>
          
          <div className="w-full bg-[#DEDEDE] rounded-full h-6 overflow-hidden shadow-inner">
            <div 
              className={`h-6 rounded-full transition-all duration-700 ${
                calculations.budgetRemaining >= 0 
                  ? 'bg-gradient-to-r from-[#9BAE8F] to-[#4A6B8A] shadow-lg' 
                  : 'bg-gradient-to-r from-[#A67676] to-[#A67676]/80 shadow-lg'
              }`}
              style={{ width: `${Math.min((calculations.todayExpenses / calculations.dailyAllowance) * 100, 100)}%` }}
            ></div>
          </div>
          
          <div className="text-center bg-gradient-to-r from-[#C4A8A8]/10 to-[#4A6B8A]/10 rounded-2xl p-6">
            <p className={`text-2xl font-bold mb-2 ${
              calculations.budgetRemaining >= 0 ? 'text-[#9BAE8F]' : 'text-[#A67676]'
            }`}>
              ${Math.abs(calculations.budgetRemaining).toFixed(2)} {calculations.budgetRemaining >= 0 ? 'remaining' : 'over budget'}
            </p>
            <p className="text-[#1A1A1A]/70 text-lg">
              {calculations.budgetRemaining >= 0 ? 'Great job staying on track!' : 'Try to reduce spending tomorrow'}
            </p>
          </div>
        </div>
      </div>

      <BudgetExplanation />
    </div>
  );

  // Daily tab content
  const DailyContent = () => (
    <div className="space-y-8">
      <div className="bg-white rounded-3xl border border-[#DEDEDE] p-8 shadow-xl">
        <h2 className="text-2xl font-bold text-[#1A1A1A] mb-6">Today's Goals</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            { key: 'trackExpenses', label: 'Track all expenses', icon: CreditCard, color: 'from-[#C4A8A8] to-[#C4A8A8]/80' },
            { key: 'stayUnderBudget', label: 'Stay under budget', icon: Target, color: 'from-[#9BAE8F] to-[#9BAE8F]/80' },
            { key: 'addToEmergency', label: 'Add to emergency fund', icon: PiggyBank, color: 'from-[#4A6B8A] to-[#4A6B8A]/80' },
            { key: 'makeDebtPayment', label: 'Make debt payment', icon: Minus, color: 'from-[#A67676] to-[#A67676]/80' }
          ].map((goal) => (
            <div key={goal.key} className="flex items-center justify-between p-6 border border-[#DEDEDE] rounded-2xl hover:shadow-lg transition-all duration-300">
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br ${goal.color} shadow-lg`}>
                  <goal.icon className="w-6 h-6 text-white" />
                </div>
                <span className="text-lg font-semibold text-[#1A1A1A]">{goal.label}</span>
              </div>
              <Button
                onClick={() => setData(prev => ({
                  ...prev,
                  dailyGoals: { ...prev.dailyGoals, [goal.key]: !prev.dailyGoals[goal.key] }
                }))}
                className={`w-12 h-12 rounded-xl transition-all duration-200 ${
                  data.dailyGoals[goal.key]
                    ? 'bg-gradient-to-r from-[#9BAE8F] to-[#4A6B8A] text-white shadow-lg'
                    : 'border border-[#DEDEDE] bg-white text-[#1A1A1A] hover:bg-[#C4A8A8]/10'
                }`}
              >
                {data.dailyGoals[goal.key] ? <Check className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
              </Button>
            </div>
          ))}
        </div>
      </div>

      <BudgetExplanation />
    </div>
  );

  // Expenses tab content
  const ExpensesContent = () => (
    <div className="space-y-8">
      <div className="bg-white rounded-3xl border border-[#DEDEDE] p-8 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-[#1A1A1A]">Today's Expenses</h2>
          <Button
            onClick={() => setShowExpenseModal(true)}
            className="bg-gradient-to-r from-[#C4A8A8] to-[#A67676] text-white px-6 py-3 rounded-xl hover:from-[#C4A8A8]/90 hover:to-[#A67676]/90 shadow-lg"
          >
            <Plus className="w-5 h-5 mr-2" />
            Add Expense
          </Button>
        </div>
        
        {data.expenses.filter(expense => {
          const expenseDate = new Date(expense.date);
          const today = new Date();
          return expenseDate.toDateString() === today.toDateString();
        }).length === 0 ? (
          <div className="text-center py-12">
            <CreditCard className="w-16 h-16 text-[#1A1A1A]/30 mx-auto mb-4" />
            <p className="text-[#1A1A1A]/70 text-lg">No expenses tracked today. Start by adding your first expense!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {data.expenses
              .filter(expense => {
                const expenseDate = new Date(expense.date);
                const today = new Date();
                return expenseDate.toDateString() === today.toDateString();
              })
              .map((expense) => (
                <div key={expense.id} className="flex items-center justify-between p-4 border border-[#DEDEDE] rounded-xl hover:shadow-lg transition-all duration-300">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-[#C4A8A8] to-[#A67676] rounded-xl flex items-center justify-center shadow-lg">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-[#1A1A1A]">{expense.description}</p>
                      <p className="text-sm text-[#1A1A1A]/70">{expense.category} • {expense.timestamp}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-[#A67676]">${expense.amount.toFixed(2)}</p>
                    <Button
                      onClick={() => {
                        setData(prev => ({
                          ...prev,
                          expenses: prev.expenses.filter(e => e.id !== expense.id)
                        }));
                        addNotification('Expense deleted', 'info');
                      }}
                      variant="ghost"
                      size="sm"
                      className="text-[#A67676] hover:bg-[#A67676]/10 mt-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
          </div>
        )}
      </div>

      <BudgetExplanation />
    </div>
  );

  // Progress tab content
  const ProgressContent = () => (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          {
            title: 'Debt Progress',
            value: `${calculations.debtProgress.toFixed(1)}%`,
            subtitle: `$${calculations.debtRemaining.toFixed(2)} remaining`,
            icon: CreditCard,
            gradient: 'from-[#A67676] to-[#A67676]/80',
            progress: calculations.debtProgress
          },
          {
            title: 'Emergency Fund',
            value: `${calculations.emergencyProgress.toFixed(1)}%`,
            subtitle: `$${data.emergencyFund}/$${data.goals.emergencyFund}`,
            icon: PiggyBank,
            gradient: 'from-[#9BAE8F] to-[#9BAE8F]/80',
            progress: calculations.emergencyProgress
          },
          {
            title: 'Independence Score',
            value: `${calculations.independenceScore}%`,
            subtitle: 'Overall Progress',
            icon: Target,
            gradient: 'from-[#4A6B8A] to-[#4A6B8A]/80',
            progress: calculations.independenceScore
          }
        ].map((card, index) => (
          <div key={index} className="bg-white rounded-2xl border border-[#DEDEDE] p-6 shadow-lg hover:shadow-xl transition-all duration-300">
            <div className="flex items-center space-x-3 mb-4">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br ${card.gradient} shadow-lg`}>
                <card.icon className="w-6 h-6 text-white" />
              </div>
              <h4 className="text-lg font-bold text-[#1A1A1A]">{card.title}</h4>
            </div>
            <p className="text-3xl font-bold text-[#1A1A1A] mb-2">{card.value}</p>
            <p className="text-sm text-[#1A1A1A]/70 mb-4">{card.subtitle}</p>
            
            <div className="w-full bg-[#DEDEDE] rounded-full h-3 shadow-inner">
              <div 
                className={`h-3 rounded-full transition-all duration-700 bg-gradient-to-r ${card.gradient} shadow-sm`}
                style={{ width: `${Math.min(card.progress, 100)}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>

      <BudgetExplanation />
    </div>
  );

  // Learn tab content
  const LearnContent = () => (
    <div className="space-y-8">
      <div className="bg-white rounded-3xl border border-[#DEDEDE] p-8 shadow-xl">
        <h2 className="text-2xl font-bold text-[#1A1A1A] mb-6">Financial Education</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[
            {
              title: 'Understanding Your Budget',
              description: 'Learn how your daily allowance is calculated and why it matters',
              icon: Calculator,
              color: 'from-[#4A6B8A] to-[#4A6B8A]/80'
            },
            {
              title: 'Debt Payoff Strategies',
              description: 'Explore different approaches to eliminate debt faster',
              icon: TrendingDown,
              color: 'from-[#A67676] to-[#A67676]/80'
            },
            {
              title: 'Emergency Fund Basics',
              description: 'Why emergency funds matter and how to build one',
              icon: PiggyBank,
              color: 'from-[#9BAE8F] to-[#9BAE8F]/80'
            },
            {
              title: 'Financial Independence',
              description: 'Steps to achieve true financial freedom',
              icon: Target,
              color: 'from-[#C4A8A8] to-[#C4A8A8]/80'
            }
          ].map((lesson, index) => (
            <div key={index} className="p-6 border border-[#DEDEDE] rounded-2xl hover:shadow-lg transition-all duration-300 cursor-pointer">
              <div className="flex items-center space-x-4 mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br ${lesson.color} shadow-lg`}>
                  <lesson.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-[#1A1A1A]">{lesson.title}</h3>
              </div>
              <p className="text-[#1A1A1A]/70">{lesson.description}</p>
            </div>
          ))}
        </div>
      </div>

      <BudgetExplanation />
    </div>
  );

  // Data tab content
  const DataContent = () => (
    <div className="space-y-8">
      <div className="bg-white rounded-3xl border border-[#DEDEDE] p-8 shadow-xl">
        <h2 className="text-2xl font-bold text-[#1A1A1A] mb-6">Export Your Data</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Button
            onClick={() => {
              const dataStr = JSON.stringify(data, null, 2);
              const dataBlob = new Blob([dataStr], {type: 'application/json'});
              const url = URL.createObjectURL(dataBlob);
              const link = document.createElement('a');
              link.href = url;
              link.download = 'max-financial-data.json';
              link.click();
              addNotification('Data exported successfully!', 'success');
            }}
            className="p-6 bg-gradient-to-r from-[#4A6B8A] to-[#C4A8A8] text-white rounded-2xl hover:from-[#4A6B8A]/90 hover:to-[#C4A8A8]/90 shadow-lg flex flex-col items-center space-y-3"
          >
            <Download className="w-8 h-8" />
            <span className="font-semibold">Export JSON</span>
          </Button>
          
          <Button
            onClick={() => addNotification('CSV export coming soon!', 'info')}
            className="p-6 bg-gradient-to-r from-[#9BAE8F] to-[#4A6B8A] text-white rounded-2xl hover:from-[#9BAE8F]/90 hover:to-[#4A6B8A]/90 shadow-lg flex flex-col items-center space-y-3"
          >
            <Download className="w-8 h-8" />
            <span className="font-semibold">Export CSV</span>
          </Button>
          
          <Button
            onClick={() => addNotification('PDF export coming soon!', 'info')}
            className="p-6 bg-gradient-to-r from-[#C4A8A8] to-[#A67676] text-white rounded-2xl hover:from-[#C4A8A8]/90 hover:to-[#A67676]/90 shadow-lg flex flex-col items-center space-y-3"
          >
            <Download className="w-8 h-8" />
            <span className="font-semibold">Export PDF</span>
          </Button>
        </div>
      </div>

      <BudgetExplanation />
    </div>
  );

  // Enhanced floating AI coach
  const FloatingAICoach = () => (
    <div className="fixed bottom-8 right-8 z-50">
      <Button
        onClick={() => setShowAIModal(true)}
        className="w-16 h-16 bg-gradient-to-br from-[#4A6B8A] to-[#A67676] rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 flex items-center justify-center text-white animate-pulse hover:scale-110 hover:animate-none border-4 border-white"
      >
        <Brain className="w-7 h-7" />
      </Button>
    </div>
  );

  // Enhanced AI Modal
  const AIModal = () => {
    if (!showAIModal) return null;

    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className={`bg-white rounded-3xl shadow-2xl border border-[#DEDEDE] ${
          responsive.isMobile ? 'w-full max-w-sm h-[85vh]' : 
          responsive.isTablet ? 'w-[85vw] h-[85vh]' : 
          'w-[650px] h-[750px]'
        } flex flex-col overflow-hidden`}>
          <div className="flex items-center justify-between p-6 border-b border-[#DEDEDE] bg-gradient-to-r from-[#4A6B8A]/5 to-[#C4A8A8]/5">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-[#4A6B8A] to-[#A67676] rounded-2xl flex items-center justify-center shadow-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-[#1A1A1A]">Fin - Your AI Coach</h3>
                <p className="text-sm text-[#1A1A1A]/70">I explain the 'why' behind your financial plan</p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowAIModal(false)}
              className="w-10 h-10 rounded-xl hover:bg-[#A67676]/10 transition-colors duration-200"
            >
              <X className="w-5 h-5 text-[#1A1A1A]" />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-[#FFFFFF] to-[#C4A8A8]/5">
            {aiConversation.length === 0 && (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-gradient-to-br from-[#4A6B8A]/10 to-[#C4A8A8]/10 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                  <Brain className="w-10 h-10 text-[#4A6B8A]" />
                </div>
                <h4 className="text-2xl font-bold text-[#1A1A1A] mb-3">Hi Max! 👋</h4>
                <p className="text-[#1A1A1A]/70 text-lg leading-relaxed mb-4">I'm Fin, your AI financial coach. I can explain why your budget is ${calculations.dailyAllowance.toFixed(2)}/day and help you adjust it based on your goals!</p>
                <div className="bg-[#4A6B8A]/5 rounded-2xl p-4 border border-[#DEDEDE]">
                  <p className="text-sm text-[#1A1A1A]/80">💡 Try asking: "Why is my daily budget ${calculations.dailyAllowance.toFixed(2)}?" or "What if I want to be debt-free sooner?"</p>
                </div>
              </div>
            )}
            
            {aiConversation.map((message, index) => (
              <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-4 rounded-2xl shadow-lg ${
                  message.role === 'user' 
                    ? 'bg-gradient-to-br from-[#4A6B8A] to-[#A67676] text-white' 
                    : 'bg-white text-[#1A1A1A] border border-[#DEDEDE]'
                }`}>
                  <p className="text-sm leading-relaxed">{message.content}</p>
                  <p className={`text-xs mt-2 ${message.role === 'user' ? 'text-white/70' : 'text-[#1A1A1A]/50'}`}>
                    {message.timestamp}
                  </p>
                </div>
              </div>
            ))}
            
            {aiLoading && (
              <div className="flex justify-start">
                <div className="bg-white p-4 rounded-2xl shadow-lg border border-[#DEDEDE]">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-[#4A6B8A] rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-[#4A6B8A] rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-2 h-2 bg-[#4A6B8A] rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                    <span className="text-sm text-[#1A1A1A]/70 ml-2">Fin is thinking...</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="p-6 border-t border-[#DEDEDE] bg-white">
            <div className="flex flex-wrap gap-3 mb-4">
              {[
                { text: 'Why ' + calculations.dailyAllowance.toFixed(2) + '?', question: 'Why is my daily budget $' + calculations.dailyAllowance.toFixed(2) + '? Can you break down the calculation?', color: 'from-[#4A6B8A] to-[#4A6B8A]/80' },
                { text: 'Adjust my goals', question: 'I want to change my debt-free date or emergency fund goal. How would that affect my budget?', color: 'from-[#C4A8A8] to-[#C4A8A8]/80' },
                { text: 'Income changed', question: 'My income or expenses have changed. How do I update my budget?', color: 'from-[#9BAE8F] to-[#9BAE8F]/80' }
              ].map((item, index) => (
                <Button
                  key={index}
                  onClick={() => handleAIQuestion(item.question)}
                  className={`px-4 py-3 text-sm rounded-xl transition-all duration-200 min-h-[44px] bg-gradient-to-r ${item.color} text-white hover:scale-105 shadow-md hover:shadow-lg border-0`}
                >
                  {item.text}
                </Button>
              ))}
            </div>
            
            <div className="flex space-x-3">
              <input
                type="text"
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && aiInput.trim() && handleAIQuestion(aiInput)}
                placeholder="Ask about your budget, goals, or any changes..."
                className="flex-1 px-4 py-3 border border-[#DEDEDE] rounded-xl focus:ring-2 focus:ring-[#4A6B8A] focus:border-[#4A6B8A] min-h-[44px] transition-all duration-200 bg-white text-[#1A1A1A] placeholder-[#1A1A1A]/50"
              />
              <Button
                onClick={() => aiInput.trim() && handleAIQuestion(aiInput)}
                disabled={!aiInput.trim() || aiLoading}
                className="px-4 py-3 bg-gradient-to-r from-[#4A6B8A] to-[#A67676] text-white rounded-xl hover:from-[#4A6B8A]/90 hover:to-[#A67676]/90 disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px] min-w-[44px] flex items-center justify-center transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="flex justify-center mt-4">
              <Button
                variant="ghost"
                onClick={() => setAiConversation([])}
                className="px-4 py-2 text-sm text-[#1A1A1A]/70 hover:bg-[#C4A8A8]/10 rounded-lg min-h-[44px] transition-colors duration-200"
              >
                Clear conversation
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Expense Modal
  const ExpenseModal = () => {
    if (!showExpenseModal) return null;

    return (
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-3xl shadow-2xl border border-[#DEDEDE] w-full max-w-md">
          <div className="flex items-center justify-between p-6 border-b border-[#DEDEDE]">
            <h3 className="text-xl font-bold text-[#1A1A1A]">Add Expense</h3>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowExpenseModal(false)}
              className="w-10 h-10 rounded-xl hover:bg-[#A67676]/10"
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
          
          <div className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-2">Amount</label>
              <input
                type="number"
                value={expenseForm.amount}
                onChange={(e) => setExpenseForm(prev => ({ ...prev, amount: e.target.value }))}
                placeholder="0.00"
                className="w-full px-4 py-3 border border-[#DEDEDE] rounded-xl focus:ring-2 focus:ring-[#4A6B8A] focus:border-[#4A6B8A] transition-all duration-200"
              />
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-2">Description</label>
              <input
                type="text"
                value={expenseForm.description}
                onChange={(e) => setExpenseForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="What did you buy?"
                className="w-full px-4 py-3 border border-[#DEDEDE] rounded-xl focus:ring-2 focus:ring-[#4A6B8A] focus:border-[#4A6B8A] transition-all duration-200"
              />
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-2">Category</label>
              <select
                value={expenseForm.category}
                onChange={(e) => setExpenseForm(prev => ({ ...prev, category: e.target.value }))}
                className="w-full px-4 py-3 border border-[#DEDEDE] rounded-xl focus:ring-2 focus:ring-[#4A6B8A] focus:border-[#4A6B8A] transition-all duration-200"
              >
                <option>Food & Dining</option>
                <option>Transportation</option>
                <option>Shopping</option>
                <option>Entertainment</option>
                <option>Bills & Utilities</option>
                <option>Healthcare</option>
                <option>Other</option>
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-semibold text-[#1A1A1A] mb-2">Date</label>
              <input
                type="date"
                value={expenseForm.date}
                onChange={(e) => setExpenseForm(prev => ({ ...prev, date: e.target.value }))}
                className="w-full px-4 py-3 border border-[#DEDEDE] rounded-xl focus:ring-2 focus:ring-[#4A6B8A] focus:border-[#4A6B8A] transition-all duration-200"
              />
            </div>
            
            <div className="flex space-x-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setShowExpenseModal(false)}
                className="flex-1 py-3 border-[#DEDEDE] hover:bg-[#A67676]/10 hover:border-[#A67676] rounded-xl"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  if (!expenseForm.amount || !expenseForm.description) {
                    addNotification('Please fill in all fields', 'error');
                    return;
                  }

                  const expense = {
                    id: Date.now(),
                    amount: parseFloat(expenseForm.amount),
                    description: expenseForm.description,
                    category: expenseForm.category,
                    date: expenseForm.date,
                    timestamp: new Date().toLocaleTimeString()
                  };
                  
                  setData(prev => ({
                    ...prev,
                    expenses: [...prev.expenses, expense]
                  }));
                  
                  setExpenseForm({
                    amount: '',
                    description: '',
                    category: 'Food & Dining',
                    date: new Date().toISOString().split('T')[0]
                  });
                  
                  setShowExpenseModal(false);
                  addNotification(`Added $${expense.amount} expense: ${expense.description}`, 'success');
                }}
                className="flex-1 py-3 bg-gradient-to-r from-[#9BAE8F] to-[#4A6B8A] text-white rounded-xl hover:from-[#9BAE8F]/90 hover:to-[#4A6B8A]/90 shadow-lg"
              >
                Add Expense
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  // Enhanced notification system
  const NotificationSystem = () => (
    <div className="fixed top-6 right-6 z-50 space-y-3">
      {notifications.map(notification => (
        <div
          key={notification.id}
          className={`px-6 py-4 rounded-2xl shadow-2xl text-white transform transition-all duration-500 border-l-4 ${
            notification.type === 'success' ? 'bg-gradient-to-r from-[#9BAE8F] to-[#4A6B8A] border-[#9BAE8F]' :
            notification.type === 'error' ? 'bg-gradient-to-r from-[#A67676] to-[#A67676]/80 border-[#A67676]' :
            'bg-gradient-to-r from-[#4A6B8A] to-[#C4A8A8] border-[#4A6B8A]'
          } animate-slide-in backdrop-blur-sm`}
        >
          <div className="flex items-center space-x-3">
            {notification.type === 'success' && <Check className="w-5 h-5 flex-shrink-0" />}
            {notification.type === 'error' && <X className="w-5 h-5 flex-shrink-0" />}
            {notification.type === 'info' && <Bell className="w-5 h-5 flex-shrink-0" />}
            <span className="font-semibold">{notification.message}</span>
          </div>
        </div>
      ))}
    </div>
  );

  // Render different content based on active tab
  const renderTabContent = () => {
    switch (activeTab) {
      case 'home':
        return <HomeContent />;
      case 'daily':
        return <DailyContent />;
      case 'expenses':
        return <ExpensesContent />;
      case 'progress':
        return <ProgressContent />;
      case 'learn':
        return <LearnContent />;
      case 'data':
        return <DataContent />;
      default:
        return <HomeContent />;
    }
  };

  // Main render
  return (
    <div className="min-h-screen bg-[#FFFFFF]">
      <Navigation />
      <NotificationSystem />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {renderTabContent()}
      </main>

      <FloatingAICoach />
      <AIModal />
      <ExpenseModal />
      <GoalSetupModal />
      
      <style jsx>{`
        @keyframes slide-in {
          from {
            transform: translateX(100%) scale(0.8);
            opacity: 0;
          }
          to {
            transform: translateX(0) scale(1);
            opacity: 1;
          }
        }
        
        .animate-slide-in {
          animation: slide-in 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        
        .shadow-3xl {
          box-shadow: 0 35px 60px -12px rgba(0, 0, 0, 0.25);
        }
        
        * {
          transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
          transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
          transition-duration: 200ms;
        }
        
        button:focus-visible,
        input:focus-visible,
        select:focus-visible {
          outline: 2px solid #4A6B8A;
          outline-offset: 2px;
        }
      `}</style>
    </div>
  );
}

export default App;

