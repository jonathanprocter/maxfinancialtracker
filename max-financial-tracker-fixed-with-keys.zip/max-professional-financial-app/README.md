# Max Professional Financial App — Fixed & AI-Enabled

## What’s new
- Secure backend proxy (`/server/index.js`) for **OpenAI** and **Anthropic**.
- Frontend now posts to `/api/ai` with a simple **provider dropdown** (OpenAI or Anthropic).
- No more client-side API keys or CORS headaches.
- `pnpm dev:all` runs Vite **and** the API server together.

## Setup
1. Copy `.env.example` → `.env` and set your keys:
   ```bash
   OPENAI_API_KEY=sk-...
   ANTHROPIC_API_KEY=sk-ant-...
   PORT=8787
   ```
2. Install deps and run:
   ```bash
   pnpm install
   pnpm dev:all
   ```
3. Visit the app, pick a provider from the **Ask Fin** panel, and chat.

## Notes
- OpenAI uses `gpt-4o-mini` by default; Anthropic uses `claude-3-5-sonnet-20240620`. Change in `server/index.js` or pass `model` in the request body.
- Health check: `GET /api/health`.
- Build remains `pnpm build` (frontend). Deploy your API server alongside the static build.
---

## Testing Keys (Hardcoded for Dev Only)
This archive contains a `.env` file **and** fallback hardcoded keys inside `server/index.js`.  
In dev or demo environments this will "just work" even if environment variables aren’t set.  
**Danger:** never deploy this configuration publicly. Rotate keys if this zip is shared.
